<?php
error_reporting (E_ALL ^ E_NOTICE);
require_once "database1.php";
if (isset($_POST['submit'])) 
{ 
    if ((!isset($_POST['electiveclass'])) || (!isset($_POST['majorclass'])) ||  
        (!isset($_POST['majortwoclass'])))
    { 
        $error = "*" . "Please fill all the required fields"; 
    } 
    else
    { 
        $electiveclass = $_POST['electiveclass']; 
        $majorclass = $_POST['majorclass']; 
        $majortwoclass = $_POST['majortwoclass']; 
       
		
		
		
		//Database connection 
$db = new Database();
$conn = $db->connect();

if ($conn) {
    $insertQuery = "INSERT INTO tblstudents (electiveclass, majorclass, majortwoclass) VALUES ('$electiveclass', '$majorclass', '$majortwoclass')";
    $db->executeQuery($conn, $insertQuery);
	$conn = null;
	echo "You have successfully registered";
} else {
     echo "Failed to connect to the database.";
    } 
 }
 
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
<title> Enrollment Form </title>
<meta charset="utf-8">
<meta name="yiewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@3.4.1/dist/css/bootstrap.min.css" integrity="sha384-HSMxcRTRxnN+Bdg0JdbxYKrThecOKuH5zCYotlSAcp1+c8xmyTe9GYg1l9a69psu" crossorigin="anonymous">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>




<body>



<div class="page-header">
  <h1>Welcome to the Enrollment Form <small>The Colorado University </small></h1>
</div>
<fieldset> 
        <form id="form2" method="post" action="enrollment.php"> 
            <?php 
                if (isset($_POST['submit'])) 
                { 
                    if (isset($error)) 
                    { 
                        echo "<p style='color:red;'>" 
                        . $error . "</p>"; 
                    } 
                } 
                ?> 
				

				Electiveclass: The current class options are Psychology and Sociology. (American Politics is avalible in Spring and Summer):
				<input type="text" name="electiveclass"/> 
                  <span style="color:red;">*</span> 
                <br> 
                <br>
				Majorclass: The current class options are Testing Software and Software Development. (Data Structures is avalible in Spring and Summer):
				<input type="text" name="majorclass"/> 
                  <span style="color:red;">*</span> 
                <br> 
                <br>
				Majorwoclass: The current class options are Scrum and Information Security (American Politics is avalible in Spring and Summer):
				<input type="text" name="majortwoclass"/> 
                  <span style="color:red;">*</span> 
                <br> 
                <br>
				
                <input type="submit" value="Submit" name="submit" /> 
 
        </form> 
    </fieldset>

  
  