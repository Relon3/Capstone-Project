<?php
    error_reporting(E_ALL ^ E_NOTICE);
	


	 

  ?>

<!DOCTYPE html>
<html lang="en">
<head>
<title> Contact Us </title>
<meta charset="utf-8">

<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@3.4.1/dist/css/bootstrap.min.css" integrity="sha384-HSMxcRTRxnN+Bdg0JdbxYKrThecOKuH5zCYotlSAcp1+c8xmyTe9GYg1l9a69psu" crossorigin="anonymous">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>




<body>
<div class="page-header">
  <h1>Contact Us <small>The Colorado University </small></h1>
</div>
<div class="list-group">
  <a href="homepage.php" class="list-group-item active">
    Home
  </a>
  <a href="#" class="list-group-item">Phone Number- 555-123-5555</a>
  <a href="#" class="list-group-item">Email: info@thecoloradouniversity.edu</a>
  <a href="#" class="list-group-item">Mission: "Stive to provide students with a safe environment and the tools needed to succeed in their classes"</a>
  <a href="#" class="list-group-item">555 South Education Drive Colorado Springs, CO 80908</a>
</div>
</nav>

</body>
</html>