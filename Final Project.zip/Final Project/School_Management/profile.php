<?php
 




?>
<!DOCTYPE html>
<html lang="en">
<head>
<title> Login Page </title>
<meta charset="utf-8">
<meta name="yiewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@3.4.1/dist/css/bootstrap.min.css" integrity="sha384-HSMxcRTRxnN+Bdg0JdbxYKrThecOKuH5zCYotlSAcp1+c8xmyTe9GYg1l9a69psu" crossorigin="anonymous">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>

</head>


<body>


<div class="page-header">
  <h1>Profile Page <small>The Colorado University </small></h1>
</div>
<nav class="navbar">
<ul class="nav nav-pills">
  <li role="presentation" class="active"><a href="profilepage.php">Profile</a></li>
  <li role="presentation" class="active"><a href="enrollment.php">Enrollment</a></li>
  <li role="presentation"><a href="homepage.php">Log Out</a></li>
</ul>
</nav>



</body>
</html>


