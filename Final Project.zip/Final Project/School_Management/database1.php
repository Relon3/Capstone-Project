<?php

class Database {

  private $host = "127.0.0.1:4306"; 
  private $db_name = "class_registration";
  private $username = "root";
  private $password = "";
  private $conn;
  
   public function connect() {   
       $this->conn = null;

       try {
           $this->conn = new PDO("mysql:host=" . $this->host . ";dbname=" . $this->db_name, $this->username, $this->password);
           $this->conn->exec("set names utf8");
        } catch(PDOException $exception) {
            echo "Connection error: " . $exception->getMessage();
		}

        return $this->conn;
   }
    
  

 
    
  

  
  // Function to execute SELECT queries

  public function executeselectQuery($con, $sql) {
  try {
	   $stmt = $con->prepare($sql);
	   $stmt->execute();
  
       $result = $stmt->fetchAll(PDO :: FETCH_ASSOC);
       return $result;
  }catch(PDOException $exception) {
         echo "Error: " . $exception->getMessage();
         return null;
	}
  }
   public function executeQuery($con, $sql) {
   try {
        $stmt = $con->prepare($sql);
        $stmt->execute();
        return $stmt->rowCount();
    } catch(PDOException $exception) {
        echo "Error: " . $exception->getMessage();
        return 0;
	}
   }
}





  



?>