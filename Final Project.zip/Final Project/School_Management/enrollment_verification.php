<?php
 
include_once('database1.php');
$db = new Database();
$conn = $db->connect();


  

  
if ($_SERVER["REQUEST_METHOD"] == "POST") 
{
     
    $emailaddress = $_POST['email'];
    $password = $_POST['password'];
	$val = $_POST['email'];
	setcookie('email', $val);
	$selectQuery = "SELECT * FROM tblStudents";
    $result = $db->executeselectQuery($conn, $selectQuery);
	
    
     
    foreach($result as $user) {
         
       if(($user['email'] == $emailaddress) && 
            ($user['password'] == $password)) {
               header("location: profilepage.php.php");
        }
        else {
            echo "<script language='javascript'>";
            echo "alert('WRONG INFORMATION, TRY AGAIN')";
            echo "</script>";
            
        }
    }
}

 
?>









<!DOCTYPE html>
<html lang="en">
<head>
<title> Enrollment Page </title>
<meta charset="utf-8">
<meta name="yiewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@3.4.1/dist/css/bootstrap.min.css" integrity="sha384-HSMxcRTRxnN+Bdg0JdbxYKrThecOKuH5zCYotlSAcp1+c8xmyTe9GYg1l9a69psu" crossorigin="anonymous">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>


<body>

<div class="page-header">
  <h1>Welcome to the Enrollment Verification <small>The Colorado University </small></h1>
</div>

<form action="enrollment_verification.php" method="post">
  
  
  <div class="mb-3">
  <label for="email" class="form-label"><b>Emailaddress</b></label>
  <input type="email" class="form-control" id="email" placeholder="Enter Email to update enrollment" name="email" required>
  
  
  <label for="password" class="form-label"><b>Password</b></label>
  <input type="password" class="form-control" id="password" placeholder="Enter password to update enrollment" name="password" required>
  <br>
  <br>
  
  <input class="btn btn-primary" type="Submit" value="Login">
  <nav class="navbar">
  <ul class="nav nav-pills">
  <li role="presentation" class="active"><a href="profilepage.php">Home</a></li>
  
  </div>

</form>

</body>
</html>