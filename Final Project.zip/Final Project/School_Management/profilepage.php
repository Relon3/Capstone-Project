<?php
 
include_once('database1.php');
$db = new Database();
$conn = $db->connect();




?>
<!DOCTYPE html>
<html lang="en">
<head>
<title> Profile Page </title>
<meta charset="utf-8">
<meta name="yiewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@3.4.1/dist/css/bootstrap.min.css" integrity="sha384-HSMxcRTRxnN+Bdg0JdbxYKrThecOKuH5zCYotlSAcp1+c8xmyTe9GYg1l9a69psu" crossorigin="anonymous">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>

</head>
<div class="page-header">
  <h1>Profile Page <small>The Colorado University </small></h1>
</div>
<nav class="navbar">
<ul class="nav nav-pills">
  <li role="presentation" class="active"><a href="">Profile</a></li>
  <li role="presentation" class="active"><a href="enrollment_verification.php">Enrollment</a></li>
  <li role="presentation"><a href="homepage.php">Log Out</a></li>
</ul>
</nav>

<body>
<html>

<?php
 if(isset($_COOKIE['email'])){  
	$emailaddress = $_COOKIE['email'];
	$selectQuery = "SELECT * FROM tblStudents WHERE email = '$emailaddress'";
    $result = $db->executeselectQuery($conn, $selectQuery);
	foreach ($result as $row)
	{
		$email = $row['email'];
		$password = $row['password'];
		$firstname = $row['firstname'];
		$lastname = $row['lastname'];
		$address = $row['address'];
		$phone = $row['phone'];
		$electiveclass = $row['electiveclass'];
		$majorclass = $row['majorclass'];
		$majortwoclass = $row['majortwoclass'];
		           echo"<h1>Student Profile</h1><br>"; 
                   echo "<table border='1'>"; 
                   echo "<thead>"; 
                   echo "<th>Student Info</th>"; 
                   echo "<th></th>"; 
                   echo "</thead>"; 
                   echo "<tr>"; 
                   echo "<td>Email Address</td>"; 
                   echo "<td>".$emailaddress."</td>"; 
                   echo "</tr>"; 
                   echo "<tr>"; 
                   echo "<td>Password</td>"; 
                   echo ""; 
                   echo "</tr>"; 
                   echo "<tr>"; 
                   echo "<td>FirstName</td>"; 
                   echo "<td>".$firstname."</td>"; 
                   echo "</tr>"; 
                   echo "<tr>"; 
                   echo "<td>LastName</td>"; 
                   echo "<td>" .$lastname."</td>"; 
                   echo "</tr>"; 
                   echo "<tr>"; 
                   echo "<td>Address</td>"; 
                   echo "<td>".$address."</td>"; 
                   echo "</tr>"; 
                   echo "<tr>"; 
				   echo "<td>Phone</td>"; 
                   echo "<td>".$phone."</td>"; 
                   echo "</tr>"; 
                   echo "<tr>";
				   echo "<td>ElectiveClass</td>"; 
                   echo "<td>".$electiveclass."</td>"; 
                   echo "</tr>"; 
                   echo "<tr>";
				   echo "<td>MajorClass</td>"; 
                   echo "<td>".$majorclass."</td>"; 
                   echo "</tr>"; 
                   echo "<tr>";
				   echo "<td>MajorTwoClass</td>"; 
                   echo "<td>".$majortwoclass."</td>"; 
                   echo "</tr>"; 
                   echo "<tr>";
	}
 }
	
