<?php
error_reporting (E_ALL ^ E_NOTICE);
require_once "database1.php";
if (isset($_POST['submit'])) 
{ 
    if ((!isset($_POST['emailaddress'])) || (!isset($_POST['password'])) ||  
        (!isset($_POST['firstname'])) || (!isset($_POST['lastname'])) ||  
        (!isset($_POST['address'])) || (!isset($_POST['phone'])) ||
		(!isset($_POST['electiveclass']))  || (!isset($_POST['majorclass'])) ||
        (!isset($_POST['majortwoclass'])))
    { 
        $error = "*" . "Please fill all the required fields"; 
    } 
    else
    { 
        $emailaddress = $_POST['emailaddress']; 
        $password = $_POST['password']; 
        $firstname = $_POST['firstname']; 
        $lastname = $_POST['lastname']; 
        $address = $_POST['address']; 
        $phone = $_POST['phone'];
		$electiveclass = $_POST['electiveclass'];
		$majorclass = $_POST['majorclass'];
		$majortwoclass = $_POST['majortwoclass'];
		
		
		
		//Database connection 
$db = new Database();
$conn = $db->connect();

if ($conn) {
    $insertQuery = "INSERT INTO tblstudents (email, password, firstname, lastname, address, phone, electiveclass, majorclass, majortwoclass) VALUES ('$emailaddress', '$password', '$firstname', '$lastname', '$address', '$phone'
	, '$electiveclass', '$majorclass', '$majortwoclass')";
    $db->executeQuery($conn, $insertQuery);
	$conn = null;
	echo "You have successfully registered"; 
	} else {
     echo "Failed to connect to the database.";
    } 
}
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
<title> Registration Form </title>
<meta charset="utf-8">
<meta name="yiewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@3.4.1/dist/css/bootstrap.min.css" integrity="sha384-HSMxcRTRxnN+Bdg0JdbxYKrThecOKuH5zCYotlSAcp1+c8xmyTe9GYg1l9a69psu" crossorigin="anonymous">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>




<body>



<div class="page-header">
  <h1>Welcome to the Registration Form <small>The Colorado University </small></h1>
</div>
  <fieldset> 
        <form id="form1" method="post" action="registrationform.php"> 
            <?php 
                if (isset($_POST['submit'])) 
                { 
                    if (isset($error)) 
                    { 
                        echo "<p style='color:red;'>" 
                        . $error . "</p>"; 
                    } 
                } 
                ?> 
				
                Emailaddress: 
                <input type="email" name="emailaddress"/>  
                 <span style="color:red;">*</span> 
                <br> 
                <br> 
                Password: 
                <input type="password" name="password"/> 
                  <span style="color:red;">*</span> 
                <br> 
                <br>  
                FirstName: 
                <input type="text" name="firstname"/> 
                  <span style="color:red;">*</span> 
                <br> 
                <br>  
                LastName: 
                <input type="text" name="lastname"/> 
                  <span style="color:red;">*</span> 
                <br> 
                <br>  
                Address: 
                <input type="text" name="address"/> 
                   <span style="color:red;">*</span> 
                <br> 
                <br>  
                Phone: 
                <input type="text" name="phone"/> 
                  <span style="color:red;">*</span> 
                <br> 
                <br>
				Electiveclass: The current class options are Psychology and Sociology. (American Politics is avalible in Spring and Summer):
				<input type="text" name="electiveclass"/> 
                  <span style="color:red;">*</span> 
                <br> 
                <br>
				Majorclass: The current class options are Testing Software and Software Development. (Data Structures is avalible in Spring and Summer):
				<input type="text" name="majorclass"/> 
                  <span style="color:red;">*</span> 
                <br> 
                <br>
				Majorwoclass: The current class options are Scrum and Information Security (American Politics is avalible in Spring and Summer):
				<input type="text" name="majortwoclass"/> 
                  <span style="color:red;">*</span> 
                <br> 
                <br>
				
                <input type="submit" value="Submit" name="submit" /> 
 
        </form> 
    </fieldset>
<nav class="navbar">
<ul class="nav nav-pills">
  <li role="presentation" class="active"><a href="homepage.php">Home</a></li>
	<?php 
      
          
    ?> 


</body>

</html>