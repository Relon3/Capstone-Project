<?php
    error_reporting(E_ALL ^ E_NOTICE);
	


	 

  ?>

<!DOCTYPE html>
<html lang="en">
<head>
<title> Home Page </title>
<meta charset="utf-8">

<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@3.4.1/dist/css/bootstrap.min.css" integrity="sha384-HSMxcRTRxnN+Bdg0JdbxYKrThecOKuH5zCYotlSAcp1+c8xmyTe9GYg1l9a69psu" crossorigin="anonymous">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>




<body>


<div class="page-header">
  <h1>Welcome to the Home Page <small>The Colorado University </small></h1>
</div>
<nav class="navbar">
<ul class="nav nav-pills">
  <li role="presentation" class="active"><a href="homepage.php">Home</a></li>
  <li role="presentation"><a href="contactus.php">Contact Us</a></li>
  <li role="presentation"><a href="login.php">Login</a></li>
  <li role="presentation"><a href="registrationform.php">Registration</a></li>
</ul>
</nav>

</body>
</html>
